import os
import json
import urllib.request

from dotenv import load_dotenv
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent

load_dotenv(PROJECT_ROOT / ".env")

WEBAPP_URL = os.getenv("EMAIL_WEBAPP_URL")
SECRET_TOKEN = os.getenv("EMAIL_SECRET_TOKEN")


def send_vendor_email(
    email,
    vendor_name,
    vendor_id,
    action
):

    if not WEBAPP_URL or not SECRET_TOKEN:
        return False, "Email configuration missing."

    data = {
        "token": SECRET_TOKEN,
        "email": email,
        "vendor_name": vendor_name,
        "vendor_id": vendor_id,
        "action": action
    }

    request_data = json.dumps(
        data
    ).encode("utf-8")

    request = urllib.request.Request(
        WEBAPP_URL,
        data=request_data,
        headers={
            "Content-Type": "application/json"
        },
        method="POST"
    )

    try:

        with urllib.request.urlopen(
            request,
            timeout=20
        ) as response:

            result = json.loads(
                response.read().decode("utf-8")
            )

        if result.get("status") == "success":
            return True, result.get("message")

        return False, result.get(
            "message",
            "Email could not be sent."
        )

    except Exception as e:

        return False, str(e)