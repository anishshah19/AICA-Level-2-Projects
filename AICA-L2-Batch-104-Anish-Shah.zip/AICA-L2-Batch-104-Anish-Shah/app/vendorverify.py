import os
import json
import tempfile
import time
from pathlib import Path
from datetime import datetime

import streamlit as st
import gspread
from dotenv import load_dotenv
from google import genai

from email_service import send_vendor_email


# =========================================================
# 1. PAGE SETTINGS
# =========================================================
st.set_page_config(
    page_title="VendorVerify",
    page_icon="✅",
    layout="wide"
)


# =========================================================
# 2. PROJECT LOCATION
# =========================================================
PROJECT_ROOT = Path(__file__).resolve().parent.parent


# =========================================================
# 3. LOAD API KEY
# =========================================================
load_dotenv(PROJECT_ROOT / ".env")

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    st.error("System configuration error: API key not found.")
    st.stop()

client = genai.Client(api_key=api_key)


# =========================================================
# 4. CONNECT TO GOOGLE SHEETS
# =========================================================
credentials_file = (
    PROJECT_ROOT
    / "credentials"
    / "google_credentials.json"
)

try:
    gc = gspread.service_account(
        filename=str(credentials_file)
    )

    spreadsheet = gc.open(
        "VendorVerify_AI_Database"
    )

    vendor_master = spreadsheet.worksheet(
        "Vendor_Master"
    )

    pending_vendors = spreadsheet.worksheet(
        "Pending_Vendors"
    )

    exception_log = spreadsheet.worksheet(
        "Exception_Log"
    )

except Exception as e:
    st.error(f"Unable to connect to Vendor Database: {e}")
    st.stop()


# =========================================================
# 5. INITIALISE SESSION
# =========================================================
if "upload_key" not in st.session_state:
    st.session_state["upload_key"] = 0


# =========================================================
# 6. START NEW VENDOR
# =========================================================
def start_new_vendor():

    keys_to_remove = [
        "vendor_data",
        "validation_results",
        "duplicate_results",
        "inconsistencies",
        "overall_passed",
        "action_completed",
        "final_action",
        "document_errors"
    ]

    for key in keys_to_remove:
        st.session_state.pop(key, None)

    st.session_state["upload_key"] += 1

    st.rerun()


# =========================================================
# 7. HEADER
# =========================================================
header_col1, header_col2 = st.columns([5, 1])

with header_col1:

    st.title("VendorVerify")

    st.subheader(
        "Vendor Onboarding & Verification System"
    )

with header_col2:

    st.write("")
    st.write("")

    if st.button(
        "Start New Vendor",
        key="start_new_vendor_top",
        use_container_width=True
    ):
        start_new_vendor()


st.write(
    "Upload applicable vendor documents below. "
    "The system will extract vendor information, verify document type, "
    "perform validation checks, check for duplicates and route the vendor "
    "for approval."
)


# =========================================================
# 8. HELPER FUNCTIONS
# =========================================================
def clean_text(value):

    if value is None:
        return ""

    return str(value).strip().upper()


def clean_bank_account(value):

    if value is None:
        return ""

    return (
        str(value)
        .strip()
        .replace(" ", "")
        .replace("-", "")
    )


# =========================================================
# 9. NEXT VENDOR ID
# =========================================================
def generate_vendor_id():

    vendor_ids = []

    for worksheet in [
        vendor_master,
        pending_vendors
    ]:

        values = worksheet.col_values(1)

        for value in values[1:]:

            value = str(value).strip().upper()

            if value.startswith("V"):

                try:
                    vendor_ids.append(
                        int(value[1:])
                    )

                except ValueError:
                    pass

    if not vendor_ids:
        return "V0001"

    return f"V{max(vendor_ids) + 1:04d}"


# =========================================================
# 10. GEMINI RETRY
# =========================================================
def generate_with_retry(contents):

    max_retries = 3

    for attempt in range(max_retries):

        try:

            return client.models.generate_content(
                model="gemini-3.5-flash-lite",
                contents=contents
            )

        except Exception as e:

            if (
                "503" in str(e)
                and attempt < max_retries - 1
            ):

                wait_time = 5 * (2 ** attempt)

                time.sleep(wait_time)

            else:
                raise


# =========================================================
# 11. CLASSIFY DOCUMENT
# =========================================================
def classify_document(gemini_file):

    classification_prompt = """
Identify the type of vendor document provided.

Return ONLY one of the following values:

PAN
GST
BANK
MSME
OTHER

Classification rules:

PAN:
Permanent Account Number document or PAN card.

GST:
GST Registration Certificate or document containing GSTIN
and GST registration particulars.

BANK:
Cancelled cheque, bank statement, bank letter or other
bank account proof containing account number and/or IFSC.

MSME:
Udyam Registration Certificate or MSME registration document.

OTHER:
Any document which does not clearly belong to the above categories.

Return only the category word.
Do not explain your answer.
"""

    response = generate_with_retry(
        [
            classification_prompt,
            gemini_file
        ]
    )

    return (
        response.text
        .strip()
        .upper()
        .replace(".", "")
    )


# =========================================================
# 12. DUPLICATE CHECK
# =========================================================
def check_duplicates(vendor_data):

    existing_vendors = vendor_master.get_all_records()

    results = {
        "PAN": None,
        "GSTIN": None,
        "Bank Account": None
    }

    new_pan = clean_text(
        vendor_data.get("pan")
    )

    new_gstin = clean_text(
        vendor_data.get("gstin")
    )

    new_bank = clean_bank_account(
        vendor_data.get("bank_account_number")
    )

    for existing_vendor in existing_vendors:

        existing_name = existing_vendor.get(
            "Vendor Name",
            "Existing Vendor"
        )

        existing_pan = clean_text(
            existing_vendor.get("PAN")
        )

        existing_gstin = clean_text(
            existing_vendor.get("GSTIN")
        )

        existing_bank = clean_bank_account(
            existing_vendor.get(
                "Bank Account Number"
            )
        )

        if (
            new_pan
            and existing_pan
            and new_pan == existing_pan
        ):
            results["PAN"] = existing_name

        if (
            new_gstin
            and existing_gstin
            and new_gstin == existing_gstin
        ):
            results["GSTIN"] = existing_name

        if (
            new_bank
            and existing_bank
            and new_bank == existing_bank
        ):
            results["Bank Account"] = existing_name

    return results


# =========================================================
# 13. VALIDATION
# =========================================================
def validate_vendor(
    vendor_data,
    pan_available,
    gst_registered,
    msme_registered
):

    validation = {}

    pan = clean_text(
        vendor_data.get("pan")
    )

    gstin = clean_text(
        vendor_data.get("gstin")
    )

    bank_account = clean_bank_account(
        vendor_data.get(
            "bank_account_number"
        )
    )

    ifsc = clean_text(
        vendor_data.get("ifsc_code")
    )

    udyam_number = clean_text(
        vendor_data.get(
            "udyam_registration_number"
        )
    )

    # PAN
    if pan_available == "Yes":

        validation["PAN Available"] = (
            "PASSED"
            if pan
            else "REVIEW REQUIRED"
        )

    else:

        validation[
            "PAN Available"
        ] = "REVIEW REQUIRED"

    # GST
    if gst_registered == "Yes":

        validation["GSTIN Available"] = (
            "PASSED"
            if gstin
            else "REVIEW REQUIRED"
        )

    else:

        validation[
            "GSTIN Available"
        ] = "NOT APPLICABLE"

    # PAN embedded in GSTIN
    if (
        pan_available == "Yes"
        and gst_registered == "Yes"
        and pan
        and gstin
        and len(gstin) >= 12
    ):

        gst_pan = gstin[2:12]

        validation[
            "PAN embedded in GSTIN matches PAN"
        ] = (
            "PASSED"
            if pan == gst_pan
            else "REVIEW REQUIRED"
        )

    else:

        validation[
            "PAN embedded in GSTIN matches PAN"
        ] = "NOT APPLICABLE"

    # BANK
    validation[
        "Bank Account Available"
    ] = (
        "PASSED"
        if bank_account
        else "REVIEW REQUIRED"
    )

    # IFSC
    validation[
        "IFSC Available"
    ] = (
        "PASSED"
        if ifsc
        else "REVIEW REQUIRED"
    )

    # MSME
    if msme_registered == "Yes":

        validation[
            "Udyam Registration Number Available"
        ] = (
            "PASSED"
            if udyam_number
            else "REVIEW REQUIRED"
        )

    else:

        validation[
            "Udyam Registration Number Available"
        ] = "NOT APPLICABLE"

    return validation


# =========================================================
# 14. CREATE GOOGLE SHEET ROW
# =========================================================
def create_vendor_row(
    vendor_id,
    vendor_data,
    status,
    onboarding_date,
    remarks
):

    return [

        vendor_id,

        vendor_data.get(
            "vendor_name", ""
        ),

        vendor_data.get(
            "pan", ""
        ),

        vendor_data.get(
            "gstin", ""
        ),

        vendor_data.get(
            "state", ""
        ),

        vendor_data.get(
            "registered_address", ""
        ),

        vendor_data.get(
            "contact_person", ""
        ),

        vendor_data.get(
            "email_id", ""
        ),

        vendor_data.get(
            "mobile_number", ""
        ),

        vendor_data.get(
            "bank_name", ""
        ),

        vendor_data.get(
            "account_holder_name", ""
        ),

        vendor_data.get(
            "bank_account_number", ""
        ),

        vendor_data.get(
            "ifsc_code", ""
        ),

        vendor_data.get(
            "msme_status", ""
        ),

        vendor_data.get(
            "udyam_registration_number", ""
        ),

        vendor_data.get(
            "msme_category", ""
        ),

        vendor_data.get(
            "vendor_category", ""
        ),

        status,

        onboarding_date,

        remarks
    ]


# =========================================================
# 15. EXCEPTION LOG
# =========================================================
def add_exception(
    vendor_data,
    exception_type,
    exception_details,
    status="Open"
):

    row = [

        datetime.now().strftime(
            "%d-%m-%Y %H:%M:%S"
        ),

        vendor_data.get(
            "vendor_name", ""
        ),

        vendor_data.get(
            "pan", ""
        ),

        exception_type,

        exception_details,

        status,

        ""
    ]

    exception_log.append_row(
        row,
        value_input_option="USER_ENTERED"
    )


# =========================================================
# 16. REGISTRATION STATUS
# =========================================================
st.markdown(
    "### 1. Vendor Registration Status"
)

upload_key = st.session_state["upload_key"]

status_col1, status_col2, status_col3 = st.columns(3)

with status_col1:

    pan_available = st.radio(
        "PAN Available?",
        ["Yes", "No"],
        horizontal=True,
        key=f"pan_available_{upload_key}"
    )

with status_col2:

    gst_registered = st.radio(
        "GST Registered?",
        ["Yes", "No"],
        horizontal=True,
        key=f"gst_registered_{upload_key}"
    )

with status_col3:

    msme_registered = st.radio(
        "MSME / Udyam Registered?",
        ["Yes", "No"],
        horizontal=True,
        key=f"msme_registered_{upload_key}"
    )


# =========================================================
# 17. DOCUMENT UPLOAD
# =========================================================
st.markdown(
    "### 2. Upload Vendor Documents"
)

col1, col2 = st.columns(2)

with col1:

    if pan_available == "Yes":

        pan_file = st.file_uploader(
            "PAN Document",
            type=[
                "pdf",
                "png",
                "jpg",
                "jpeg"
            ],
            key=f"pan_{upload_key}"
        )

    else:

        pan_file = None

        st.info(
            "PAN document not available."
        )

    if gst_registered == "Yes":

        gst_file = st.file_uploader(
            "GST Certificate",
            type=[
                "pdf",
                "png",
                "jpg",
                "jpeg"
            ],
            key=f"gst_{upload_key}"
        )

    else:

        gst_file = None

        st.info(
            "GST Certificate not applicable."
        )

with col2:

    bank_file = st.file_uploader(
        "Bank Proof / Cancelled Cheque",
        type=[
            "pdf",
            "png",
            "jpg",
            "jpeg"
        ],
        key=f"bank_{upload_key}"
    )

    if msme_registered == "Yes":

        msme_file = st.file_uploader(
            "MSME / Udyam Certificate",
            type=[
                "pdf",
                "png",
                "jpg",
                "jpeg"
            ],
            key=f"msme_{upload_key}"
        )

    else:

        msme_file = None

        st.info(
            "MSME / Udyam Certificate not applicable."
        )


# =========================================================
# 18. CONTACT INFORMATION
# =========================================================
st.markdown(
    "### 3. Vendor Contact Information"
)

col3, col4 = st.columns(2)

with col3:

    contact_person = st.text_input(
        "Contact Person",
        key=f"contact_{upload_key}"
    )

    email_id = st.text_input(
        "Email ID",
        key=f"email_{upload_key}"
    )

with col4:

    mobile_number = st.text_input(
        "Mobile Number",
        key=f"mobile_{upload_key}"
    )

    vendor_category = st.selectbox(
        "Vendor Category",
        [
            "Select",
            "Goods",
            "Services",
            "Consultant",
            "Other"
        ],
        key=f"category_{upload_key}"
    )


# =========================================================
# 19. EXTRACTION PROMPT
# =========================================================
extraction_prompt = """
You are an assistant for vendor onboarding.

Review all vendor documents provided.

Extract the following information exactly as stated
in the documents:

1. Vendor Name
2. PAN
3. GSTIN
4. State
5. Registered Address
6. Bank Name
7. Account Holder Name
8. Bank Account Number
9. IFSC Code
10. MSME Status
11. Udyam Registration Number
12. MSME Category

Rules:

- Do not guess or invent information.
- If a field is unavailable, return null.
- Preserve PAN, GSTIN, IFSC, bank account number
  and Udyam Registration Number exactly as written.
- Compare names appearing across the documents.
- Identify any material inconsistency.
- Return ONLY valid JSON.
- Do not use markdown or JSON code fences.

Use exactly this structure:

{
    "vendor_name": "",
    "pan": "",
    "gstin": "",
    "state": "",
    "registered_address": "",
    "bank_name": "",
    "account_holder_name": "",
    "bank_account_number": "",
    "ifsc_code": "",
    "msme_status": "",
    "udyam_registration_number": "",
    "msme_category": "",
    "document_inconsistencies": []
}
"""


# =========================================================
# 20. VERIFY BUTTON
# =========================================================
st.markdown(
    "### 4. Verification"
)

if st.button(
    "Verify Vendor",
    type="primary"
):

    # Clear previous verification results
    for key in [
        "vendor_data",
        "validation_results",
        "duplicate_results",
        "inconsistencies",
        "overall_passed",
        "action_completed",
        "final_action",
        "document_errors"
    ]:
        st.session_state.pop(
            key,
            None
        )

    required_missing = []

    if (
        pan_available == "Yes"
        and pan_file is None
    ):
        required_missing.append(
            "PAN Document"
        )

    if (
        gst_registered == "Yes"
        and gst_file is None
    ):
        required_missing.append(
            "GST Certificate"
        )

    if bank_file is None:
        required_missing.append(
            "Bank Proof / Cancelled Cheque"
        )

    if (
        msme_registered == "Yes"
        and msme_file is None
    ):
        required_missing.append(
            "MSME / Udyam Certificate"
        )

    if not email_id.strip():
        required_missing.append(
            "Email ID"
        )

    if vendor_category == "Select":
        required_missing.append(
            "Vendor Category"
        )

    if required_missing:

        st.error(
            "Please complete the following before verification: "
            + ", ".join(required_missing)
        )

    else:

        try:

            with st.spinner(
                "Checking and analysing vendor documents..."
            ):

                uploaded_map = {}

                if pan_file:

                    uploaded_map[
                        "PAN"
                    ] = pan_file

                if gst_file:

                    uploaded_map[
                        "GST"
                    ] = gst_file

                uploaded_map[
                    "BANK"
                ] = bank_file

                if msme_file:

                    uploaded_map[
                        "MSME"
                    ] = msme_file

                gemini_files = {}

                document_errors = []

                with tempfile.TemporaryDirectory() as temp_dir:

                    # -------------------------------------
                    # Upload and classify documents
                    # -------------------------------------
                    for (
                        expected_type,
                        uploaded_file
                    ) in uploaded_map.items():

                        temporary_path = (
                            Path(temp_dir)
                            / uploaded_file.name
                        )

                        with open(
                            temporary_path,
                            "wb"
                        ) as f:

                            f.write(
                                uploaded_file.getbuffer()
                            )

                        gemini_file = client.files.upload(
                            file=str(
                                temporary_path
                            )
                        )

                        gemini_files[
                            expected_type
                        ] = gemini_file

                        detected_type = (
                            classify_document(
                                gemini_file
                            )
                        )

                        if (
                            detected_type
                            != expected_type
                        ):

                            document_errors.append(
                                (
                                    f"The document uploaded under "
                                    f"{expected_type} appears to be "
                                    f"a {detected_type} document."
                                )
                            )

                    # -------------------------------------
                    # WRONG DOCUMENTS
                    # -------------------------------------
                    if document_errors:

                        st.session_state[
                            "document_errors"
                        ] = document_errors

                    # -------------------------------------
                    # EXTRACT INFORMATION
                    # -------------------------------------
                    else:

                        contents = [
                            extraction_prompt
                        ]

                        for (
                            document_type,
                            gemini_file
                        ) in gemini_files.items():

                            contents.append(
                                (
                                    f"This is the "
                                    f"{document_type} document:"
                                )
                            )

                            contents.append(
                                gemini_file
                            )

                        response = generate_with_retry(
                            contents
                        )

                        result_text = (
                            response.text
                            .strip()
                            .replace(
                                "```json",
                                ""
                            )
                            .replace(
                                "```",
                                ""
                            )
                            .strip()
                        )

                        vendor_data = json.loads(
                            result_text
                        )

                        # ---------------------------------
                        # NOT APPLICABLE FIELDS
                        # ---------------------------------
                        if pan_available == "No":

                            vendor_data[
                                "pan"
                            ] = ""

                        if gst_registered == "No":

                            vendor_data[
                                "gstin"
                            ] = ""

                        if msme_registered == "No":

                            vendor_data[
                                "msme_status"
                            ] = "No"

                            vendor_data[
                                "udyam_registration_number"
                            ] = ""

                            vendor_data[
                                "msme_category"
                            ] = ""

                        # ---------------------------------
                        # MANUAL INFORMATION
                        # ---------------------------------
                        vendor_data[
                            "contact_person"
                        ] = contact_person

                        vendor_data[
                            "email_id"
                        ] = email_id

                        vendor_data[
                            "mobile_number"
                        ] = mobile_number

                        vendor_data[
                            "vendor_category"
                        ] = vendor_category

                        # ---------------------------------
                        # VALIDATION
                        # ---------------------------------
                        validation_results = (
                            validate_vendor(
                                vendor_data,
                                pan_available,
                                gst_registered,
                                msme_registered
                            )
                        )

                        # ---------------------------------
                        # DUPLICATES
                        # ---------------------------------
                        duplicate_results = (
                            check_duplicates(
                                vendor_data
                            )
                        )

                        inconsistencies = vendor_data.get(
                            "document_inconsistencies",
                            []
                        )

                        if not isinstance(
                            inconsistencies,
                            list
                        ):
                            inconsistencies = [
                                str(inconsistencies)
                            ]

                        review_required = any(
                            result
                            == "REVIEW REQUIRED"
                            for result
                            in validation_results.values()
                        )

                        duplicate_found = any(
                            duplicate_results.values()
                        )

                        consistency_issue = (
                            len(inconsistencies) > 0
                        )

                        overall_passed = not (
                            review_required
                            or duplicate_found
                            or consistency_issue
                        )

                        st.session_state[
                            "vendor_data"
                        ] = vendor_data

                        st.session_state[
                            "validation_results"
                        ] = validation_results

                        st.session_state[
                            "duplicate_results"
                        ] = duplicate_results

                        st.session_state[
                            "inconsistencies"
                        ] = inconsistencies

                        st.session_state[
                            "overall_passed"
                        ] = overall_passed

                        st.session_state[
                            "action_completed"
                        ] = False

        except json.JSONDecodeError:

            st.error(
                "The documents could not be processed "
                "in the expected format."
            )

        except Exception as e:

            if "503" in str(e):

                st.error(
                    "The document processing service "
                    "is temporarily busy. Please try again."
                )

            else:

                st.error(
                    f"Error during verification: {e}"
                )


# =========================================================
# 21. WRONG DOCUMENT RESULTS
# =========================================================
if st.session_state.get(
    "document_errors"
):

    st.markdown(
        "### Document Upload Issues"
    )

    for error in st.session_state[
        "document_errors"
    ]:

        st.error(
            f"Incorrect Document: {error}"
        )

    st.info(
        "Replace the incorrect document(s) above "
        "and click Verify Vendor again."
    )


# =========================================================
# 22. DISPLAY RESULTS
# =========================================================
if "vendor_data" in st.session_state:

    vendor_data = st.session_state[
        "vendor_data"
    ]

    validation_results = st.session_state[
        "validation_results"
    ]

    duplicate_results = st.session_state[
        "duplicate_results"
    ]

    inconsistencies = st.session_state[
        "inconsistencies"
    ]

    overall_passed = st.session_state[
        "overall_passed"
    ]

    st.success(
        "Vendor documents successfully analysed."
    )

    # -----------------------------------------------------
    # EXTRACTED INFORMATION
    # -----------------------------------------------------
    st.markdown(
        "### Extracted Vendor Information"
    )

    col5, col6 = st.columns(2)

    with col5:

        st.write(
            "**Vendor Name:**",
            vendor_data.get(
                "vendor_name"
            )
        )

        st.write(
            "**PAN:**",
            vendor_data.get("pan")
            or "Not Available"
        )

        st.write(
            "**GSTIN:**",
            vendor_data.get("gstin")
            or "Not Applicable"
        )

        st.write(
            "**State:**",
            vendor_data.get(
                "state"
            )
        )

        st.write(
            "**Registered Address:**",
            vendor_data.get(
                "registered_address"
            )
        )

        st.write(
            "**MSME Status:**",
            vendor_data.get(
                "msme_status"
            )
        )

    with col6:

        st.write(
            "**Bank Name:**",
            vendor_data.get(
                "bank_name"
            )
        )

        st.write(
            "**Account Holder:**",
            vendor_data.get(
                "account_holder_name"
            )
        )

        st.write(
            "**Bank Account:**",
            vendor_data.get(
                "bank_account_number"
            )
        )

        st.write(
            "**IFSC:**",
            vendor_data.get(
                "ifsc_code"
            )
        )

        st.write(
            "**Udyam Number:**",
            vendor_data.get(
                "udyam_registration_number"
            )
            or "Not Applicable"
        )

        st.write(
            "**MSME Category:**",
            vendor_data.get(
                "msme_category"
            )
            or "Not Applicable"
        )

    # -----------------------------------------------------
    # CONSISTENCY
    # -----------------------------------------------------
    st.markdown(
        "### Document Consistency Check"
    )

    if not inconsistencies:

        st.success(
            "No material inconsistency detected."
        )

    else:

        for issue in inconsistencies:
            st.warning(issue)

    # -----------------------------------------------------
    # VALIDATION
    # -----------------------------------------------------
    st.markdown(
        "### Validation Checks"
    )

    for (
        check_name,
        result
    ) in validation_results.items():

        if result == "PASSED":

            st.success(
                f"{check_name}: PASSED"
            )

        elif result == "NOT APPLICABLE":

            st.info(
                f"{check_name}: NOT APPLICABLE"
            )

        else:

            st.error(
                f"{check_name}: REVIEW REQUIRED"
            )

    # -----------------------------------------------------
    # DUPLICATES
    # -----------------------------------------------------
    st.markdown(
        "### Duplicate Vendor Check"
    )

    for field_name in [
        "PAN",
        "GSTIN",
        "Bank Account"
    ]:

        duplicate_vendor = (
            duplicate_results[
                field_name
            ]
        )

        if duplicate_vendor:

            st.error(
                f"{field_name}: Duplicate found "
                f"against {duplicate_vendor}"
            )

        else:

            st.success(
                f"{field_name}: No duplicate found"
            )

    # -----------------------------------------------------
    # OVERALL STATUS
    # -----------------------------------------------------
    st.markdown(
        "### Overall Vendor Verification"
    )

    if overall_passed:

        st.success(
            "VENDOR VERIFICATION STATUS: PASSED"
        )

    else:

        st.error(
            "VENDOR VERIFICATION STATUS: "
            "REVIEW REQUIRED"
        )


    # =====================================================
    # 23. APPROVAL WORKFLOW
    # =====================================================
    st.markdown(
        "### 5. Approval Action"
    )

    if not st.session_state.get(
        "action_completed",
        False
    ):

        approve_col, request_col, reject_col = (
            st.columns(3)
        )

        with approve_col:

            approve_clicked = st.button(
                "Approve Vendor",
                type="primary",
                disabled=not overall_passed
            )

        with request_col:

            request_clicked = st.button(
                "Request Documents"
            )

        with reject_col:

            reject_clicked = st.button(
                "Reject Vendor"
            )


        # =================================================
        # APPROVE
        # =================================================
        if approve_clicked:

            vendor_id = generate_vendor_id()

            onboarding_date = (
                datetime.now().strftime(
                    "%d-%m-%Y"
                )
            )

            row = create_vendor_row(
                vendor_id,
                vendor_data,
                "Approved",
                onboarding_date,
                "Approved through VendorVerify"
            )

            vendor_master.append_row(
                row,
                value_input_option="USER_ENTERED"
            )

            email_success, email_message = (
                send_vendor_email(
                    email=vendor_data.get(
                        "email_id",
                        ""
                    ),
                    vendor_name=vendor_data.get(
                        "vendor_name",
                        "Vendor"
                    ),
                    vendor_id=vendor_id,
                    action="approved"
                )
            )

            st.session_state[
                "action_completed"
            ] = True

            if email_success:

                st.session_state[
                    "final_action"
                ] = (
                    f"Vendor {vendor_id} successfully "
                    f"approved and added to Vendor Master. "
                    f"Approval email sent successfully."
                )

            else:

                st.session_state[
                    "final_action"
                ] = (
                    f"Vendor {vendor_id} successfully "
                    f"approved and added to Vendor Master. "
                    f"Email could not be sent: "
                    f"{email_message}"
                )

            st.rerun()


        # =================================================
        # REQUEST DOCUMENTS
        # =================================================
        if request_clicked:

            vendor_id = generate_vendor_id()

            row = create_vendor_row(
                vendor_id,
                vendor_data,
                "Pending - Documents Required",
                "",
                "Additional documents / clarification required"
            )

            pending_vendors.append_row(
                row,
                value_input_option="USER_ENTERED"
            )

            # Log validation failures
            for (
                check_name,
                result
            ) in validation_results.items():

                if (
                    result
                    == "REVIEW REQUIRED"
                ):

                    add_exception(
                        vendor_data,
                        "Validation Failure",
                        check_name
                    )

            # Log duplicates
            for (
                field_name,
                existing_vendor
            ) in duplicate_results.items():

                if existing_vendor:

                    add_exception(
                        vendor_data,
                        "Duplicate Check",
                        (
                            f"{field_name} already "
                            f"exists against "
                            f"{existing_vendor}"
                        )
                    )

            # Log inconsistencies
            for issue in inconsistencies:

                add_exception(
                    vendor_data,
                    "Document Inconsistency",
                    issue
                )

            email_success, email_message = (
                send_vendor_email(
                    email=vendor_data.get(
                        "email_id",
                        ""
                    ),
                    vendor_name=vendor_data.get(
                        "vendor_name",
                        "Vendor"
                    ),
                    vendor_id=vendor_id,
                    action="documents_required"
                )
            )

            st.session_state[
                "action_completed"
            ] = True

            if email_success:

                st.session_state[
                    "final_action"
                ] = (
                    f"Vendor {vendor_id} moved to "
                    f"Pending Vendors. "
                    f"Document request email sent successfully."
                )

            else:

                st.session_state[
                    "final_action"
                ] = (
                    f"Vendor {vendor_id} moved to "
                    f"Pending Vendors. "
                    f"Email could not be sent: "
                    f"{email_message}"
                )

            st.rerun()


        # =================================================
        # REJECT
        # =================================================
        if reject_clicked:

            vendor_id = generate_vendor_id()

            row = create_vendor_row(
                vendor_id,
                vendor_data,
                "Rejected",
                "",
                "Vendor onboarding rejected"
            )

            pending_vendors.append_row(
                row,
                value_input_option="USER_ENTERED"
            )

            add_exception(
                vendor_data,
                "Vendor Rejected",
                "Vendor onboarding rejected",
                status="Closed"
            )

            email_success, email_message = (
                send_vendor_email(
                    email=vendor_data.get(
                        "email_id",
                        ""
                    ),
                    vendor_name=vendor_data.get(
                        "vendor_name",
                        "Vendor"
                    ),
                    vendor_id=vendor_id,
                    action="rejected"
                )
            )

            st.session_state[
                "action_completed"
            ] = True

            if email_success:

                st.session_state[
                    "final_action"
                ] = (
                    f"Vendor {vendor_id} has been rejected. "
                    f"Status email sent successfully."
                )

            else:

                st.session_state[
                    "final_action"
                ] = (
                    f"Vendor {vendor_id} has been rejected. "
                    f"Email could not be sent: "
                    f"{email_message}"
                )

            st.rerun()

    else:

        st.success(
            st.session_state.get(
                "final_action",
                "Action completed."
            )
        )