VENDORVERIFY
Vendor Onboarding & Verification System
=========================================


1. PROJECT OVERVIEW
-------------------

VendorVerify is a browser-based vendor onboarding application developed as an AICA Level 2 Capstone Project.

The application:

- Accepts PAN, GST, Bank and MSME/Udyam documents
- Detects documents uploaded under the wrong category
- Extracts structured vendor information from documents
- Performs rule-based validation
- Checks duplicate PAN, GSTIN and Bank Account Number
- Identifies document inconsistencies
- Maintains approved and pending vendor records in Google Sheets
- Logs exceptions
- Supports Approve / Request Documents / Reject workflow
- Automatically sends vendor emails through Google Apps Script


2. TECHNOLOGIES USED
--------------------

Python
Streamlit
Google Gemini API
Google Sheets
Google Apps Script
Google Cloud Service Account


3. PROJECT FILES
----------------

app/vendorverify.py
Main Streamlit application.

app/email_service.py
Connects the Streamlit application with the Google Apps Script email service.

sample_documents/
Contains sample PAN, GST, Bank and MSME/Udyam documents for testing.

prompts/Prompts_Used.txt
Contains the prompts used for document classification and information extraction.

documentation/Project_Summary.txt
Contains the detailed project description and workflow.

scripts/VendorVerify_Email_Automation.gs
Google Apps Script used for automatic vendor email communication.

requirements.txt
Python libraries required to run the application.

.env.example
Example environment-variable configuration without actual passwords, API keys or security tokens.


4. SYSTEM REQUIREMENTS
----------------------

Recommended Python version:
Python 3.13

Internet connection is required because the application uses:

- Google Gemini API
- Google Sheets
- Google Apps Script


5. INSTALL REQUIRED PYTHON LIBRARIES
------------------------------------

Open Command Prompt in the project folder and run:

pip install -r requirements.txt


6. ENVIRONMENT CONFIGURATION
----------------------------

Create a file named:

.env

in the main project folder.

The file should contain:

GEMINI_API_KEY=YOUR_GEMINI_API_KEY
EMAIL_WEBAPP_URL=YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL
EMAIL_SECRET_TOKEN=YOUR_PRIVATE_EMAIL_TOKEN

The actual credentials have intentionally NOT been included in the capstone submission for security reasons.


7. GOOGLE SERVICE ACCOUNT
-------------------------

Create the following folder in the main project directory:

credentials

Place the Google Cloud service-account JSON credential file inside it and rename the file to:

google_credentials.json

Final location:

credentials/google_credentials.json

The Google Sheet used as the database must also be shared with the service-account email address.


8. GOOGLE SHEETS DATABASE
-------------------------

Create a Google Spreadsheet named:

VendorVerify_AI_Database

It must contain the following worksheets:

Vendor_Master
Pending_Vendors
Exception_Log


Vendor_Master and Pending_Vendors columns:

Vendor ID
Vendor Name
PAN
GSTIN
State
Registered Address
Contact Person
Email ID
Mobile Number
Bank Name
Account Holder Name
Bank Account Number
IFSC Code
MSME Status
Udyam Registration No.
MSME Category
Vendor Category
Approval Status
Onboarding Date
Remarks


Exception_Log columns:

Date & Time
Vendor Name
PAN
Exception Type
Exception Details
Status
Resolution Remarks


9. GOOGLE APPS SCRIPT
---------------------

The Apps Script source code is provided in:

scripts/VendorVerify_Email_Automation.gs

Deploy the script as a Google Apps Script Web App.

Configure the same private security token in:

1. Google Apps Script
2. EMAIL_SECRET_TOKEN in the .env file

The deployed Web App URL should be entered as:

EMAIL_WEBAPP_URL


10. RUNNING THE APPLICATION
---------------------------

Open Command Prompt in the main project folder.

Run:

streamlit run app\vendorverify.py

Streamlit will open VendorVerify in the browser.


11. SAMPLE TEST
---------------

Sample documents are available in:

sample_documents

For a normal vendor test:

1. Select PAN Available = Yes
2. Select GST Registered = Yes
3. Select MSME / Udyam Registered = Yes
4. Upload the corresponding sample PAN document
5. Upload the sample GST document
6. Upload the sample Bank document
7. Upload the sample MSME document
8. Enter Contact Person
9. Enter a valid Email ID
10. Enter Mobile Number
11. Select Vendor Category
12. Click Verify Vendor


12. EXPECTED PROCESS
--------------------

VendorVerify will:

1. Check whether each document has been uploaded under the correct document type
2. Extract vendor information
3. Perform validation checks
4. Compare PAN, GSTIN and Bank Account against the Vendor Master
5. Display the overall verification result
6. Allow the user to Approve, Request Documents or Reject the vendor
7. Update Google Sheets
8. Send the relevant vendor email automatically


13. SECURITY NOTE
-----------------

For security reasons, the following items are intentionally excluded from the submission:

- Actual Gemini API key
- Actual .env file
- Google service-account credential JSON
- Google Apps Script secret token
- Python virtual environment

The .env.example file demonstrates the required configuration without exposing confidential credentials.


14. AUTHOR
----------

Capstone Project:
VendorVerify – Vendor Onboarding & Verification System

Developed as part of AICA Level 2 Capstone Project.