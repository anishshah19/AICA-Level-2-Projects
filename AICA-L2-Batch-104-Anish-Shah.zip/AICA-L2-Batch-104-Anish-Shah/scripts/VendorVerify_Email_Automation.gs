function doPost(e) {

  try {

    var data = JSON.parse(e.postData.contents);

    // Simple security token
    var SECRET_TOKEN = "YOUR_PRIVATE_EMAIL_TOKEN_HERE";

    if (data.token !== SECRET_TOKEN) {
      return ContentService
        .createTextOutput(JSON.stringify({
          status: "error",
          message: "Unauthorized"
        }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    var recipient = data.email;
    var vendorName = data.vendor_name;
    var vendorId = data.vendor_id;
    var action = data.action;

    var subject = "";
    var body = "";

    // ---------------------------------------
    // APPROVED
    // ---------------------------------------
    if (action === "approved") {

      subject = "Vendor Registration Approved";

      body =
        "Dear " + vendorName + ",\n\n" +
        "Your vendor registration has been approved successfully.\n\n" +
        "Vendor ID: " + vendorId + "\n\n" +
        "Regards,\n" +
        "VendorVerify";
    }

    // ---------------------------------------
    // REQUEST DOCUMENTS
    // ---------------------------------------
    else if (action === "documents_required") {

      subject = "Additional Documents Required for Vendor Registration";

      body =
        "Dear " + vendorName + ",\n\n" +
        "Your vendor registration has been reviewed.\n\n" +
        "Additional documents or clarification are required " +
        "before the onboarding process can be completed.\n\n" +
        "Please contact the Finance Team for further details.\n\n" +
        "Regards,\n" +
        "VendorVerify";
    }

    // ---------------------------------------
    // REJECTED
    // ---------------------------------------
    else if (action === "rejected") {

      subject = "Vendor Registration Status";

      body =
        "Dear " + vendorName + ",\n\n" +
        "Your vendor registration request has not been approved.\n\n" +
        "Please contact the Finance Team if any clarification is required.\n\n" +
        "Regards,\n" +
        "VendorVerify";
    }

    else {

      return ContentService
        .createTextOutput(JSON.stringify({
          status: "error",
          message: "Invalid action"
        }))
        .setMimeType(ContentService.MimeType.JSON);
    }


    MailApp.sendEmail(
      recipient,
      subject,
      body
    );


    return ContentService
      .createTextOutput(JSON.stringify({
        status: "success",
        message: "Email sent successfully"
      }))
      .setMimeType(ContentService.MimeType.JSON);


  } catch (error) {

    return ContentService
      .createTextOutput(JSON.stringify({
        status: "error",
        message: error.toString()
      }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}